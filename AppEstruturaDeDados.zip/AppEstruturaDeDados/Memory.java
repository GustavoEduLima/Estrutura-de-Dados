package Main;

public class Memory{
	public static void main(String [] args) {
		Runtime rt = Runtime.getRuntime();
		
		System.out.println("Memoria total alocada para a JVM: " + rt.totalMemory() + "Bytes");
		
		//Executando o Gabage Colletor
		
		rt.gc();
		System.out.println("Memoria total apos executar o GC: " + rt.totalMemory() + "Bytes");
	
		
		//Memória livre antes da alocação do array
		
		long memBefore = rt.freeMemory();
		System.out.println("Memoria disponível antes da criação dos objetos: " + memBefore + "Bytes");
	
		//Criando um grande de doubles (Double são numeros decimais)
		
		double[] vetor = new double [100000];
		
		
		// Memoria livre apos a criação do Array
		
		long memAfter = rt.freeMemory();
		System.out.println("Memoria disponível antes da criação dos objetos: " + memAfter + "Bytes");
		
		//Calculando a memoria utilizada pelo array(Objetos)
		
		long memUsed = memBefore - memAfter;
		System.out.println("Memoria utilizada pelo array: " + memUsed + "Bytes");
	
		//Executando o Gabage Colletor
		
		rt.gc();
		System.out.println("Memoria total apos executar o GC: " + rt.totalMemory() + "Bytes");
	}
	
}