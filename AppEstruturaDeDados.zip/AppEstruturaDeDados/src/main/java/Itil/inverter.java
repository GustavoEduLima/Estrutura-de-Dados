package Itil;

import java.util.Scanner;

public class inverter {
	
	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		
		//Solicita ao usuário a quantidade de números que deseja inserir
		System.out.println("Digite a quantidade de numeros: ");
		int quantidade = scn.nextInt();
				
		//Criando um vetor para armazenar os numeros
		int[] numeros = new int[quantidade];
		
		//Lendo os numero fornecidos pelo usuario
		System.out.println("Digite os numeros: ");
		for (int i = 0; i < quantidade; i++){
			numeros[i] = scn.nextInt();
		}
		
		//exibindo os numeros na ordem inversa
		System.out.println("numeros na ordem inversa ");
		for(int i1 = quantidade - 1; i1 >= 0; i1--){
			System.out.println(numeros[i1] + " ");
		}
		
	}
}